# 《讲义写作指南·v4》模板包（Course auxiliary template）

本模板包将 v4 指南拆分为多个 `.md` 模板，便于在课程仓库中批量创建与复用。

## 包含文件
- 01_Lecture_Master_Template.md —— 单节讲义一体化模板（含“元信息前言”+“统一骨架”）
- 02_Meta_Preamble_Template.md —— 元信息前言一屏模板
- 03_Section_Structure_Template.md —— 统一骨架（v4）编写提示
- 04_Personal_Exercise_Template.md —— 个人练习模板（绑定个人知识库）
- 05_Group_Discussion_Template.md —— 小组讨论（画布协作）模板
- 06_Evidence_Package_Checklist.md —— 证据组合包目录与命名清单
- 07_Rubric_DoD_Checklist.md —— 评分 Rubric 与 DoD 勾选清单
- 08_Quality_Gates_TA_SOP.md —— 质量闸门与助教执行 SOP
- 09_Toolchain_Strategy.md —— 工具与环境策略（最小可跑 + 替代路径）
- 10_Prompt_Skeleton.md —— 提示词骨架（可复用变量位）
- 11_Evaluation_Metrics_RAGAS.md —— 评测口径模板（RAGAS 三指标）
- canvas/AI_Project_Canvas.md —— AI 项目画布（团队）
- canvas/Personal_Learning_Canvas.md —— 个人学习画布（个人）
- canvas/AI_Ethics_Canvas.md —— AI 伦理画布（团队）

> 用法：复制到你的课程仓库（如 `docs/templates/`），按需引用。
