# 评测口径模板（RAGAS 三指标）

## 指标定义
- **忠实度（Faithfulness）**：回答中的陈述是否可由已检索证据直接支持。
- **支持度（Answer Support）**：引用片段与回答的一致性强度。
- **召回（Context Recall）**：检索片段对问题要点的覆盖率。

## 统计口径与阈值
- 样本量：建议采样 ≥ 50（说明采样方法与时间范围）。
- 阈值建议：忠实度 ≥ __；支持度 ≥ __；召回 ≥ __（课程可统一给定）。
- 置信区间：给出区间或误差范围的说明。

## 日志字段（建议）
`query, retrieved_ids, reranker_score, final_answer, citations, ragas_scores, timestamp`

## 报告要求
- 展示分布（直方/箱线）与典型错误 Top-5 案例。
- 给出改进计划：提示词/检索策略/数据清洗/微调方案。
