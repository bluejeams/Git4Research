# 证据组合包（目录与命名清单）

```
/evidence/
  canvas/       # 三张画布快照（前/后）
  experiments/  # 解析与索引配置、重排/阈值、脚本与参数
  metrics/      # RAGAS 报表、交互日志分析、对照实验
  reflection/   # 吉布斯循环日志、间隔复习计划与跟踪
  ethics/       # 伦理风险评估与缓解记录
  demo/         # Streamlit/Gradio 原型与路演视频链接
```

- 命名：`模块-节-学号-姓名-YYYYMMDD-版本.md/json`
- 报表必须包含：统计口径、阈值、最小采样数（建议 ≥ 50）
- 所有链接**可点击**，数据**可复现**，图表**可读**
