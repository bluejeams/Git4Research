# 工具与环境策略（最小可跑 + 替代路径）

## 最小组合（离线优先）
- Ollama + LangChain + Chroma + Streamlit + RAGAS

## 质量增强
- Embedding：Qwen3-Embedding
- 重排：Qwen3-Reranker（二阶段重排）
- 解析：PyMuPDF / Unstructured（视资料类型与语言选择）

## 工程化（可选）
- 服务化：FastAPI
- 打包与环境：Docker / uv
- 向量库替代：FAISS / Qdrant
- 前端替代：Gradio

> 选择替代件请注明：触发条件（规模/隐私/算力）、收益与成本、回滚方案。
